using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum PowerUpId
{
    Nothing = 0,
    BluePotion = 1,
    RedPotion = 2
}
