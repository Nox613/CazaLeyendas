using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum SceneId
{
    Level1_1 = 0x010100,
    Level1_2 = 0x010200,
    
    //Niveles para terminar proximamente
    /*Level1_3 = 0x010300,
    Level1_4 = 0x010400,
    Level1_5 = 0x010500,
    Level1_6 = 0x010600,
    Level1_7 = 0x010700,
    LevelBoss =0*010800,*/
    
}
